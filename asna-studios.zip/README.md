# ASNA — Affection Studios (Vite + React + Tailwind)

This is a deploy-ready project for **Affection Studios | Narrative Albums (ASNA)**.
Preview subdomain requested: **asna-studios**

## Quick start (locally)
1. Install Node.js (>=18).\
2. Run: `npm install`\
3. Run dev server: `npm run dev`\

## Build for production
`npm run build`

## Deploy to Vercel (suggested) and set project name to get:
`https://asna-studios.vercel.app`

Using Vercel CLI:
1. `npm i -g vercel`\
2. `vercel login`\
3. From project root: `vercel --prod --name asna-studios`

Or use Vercel dashboard -> New Project -> Import from Git (GitHub). Set project name `asna-studios` to get that subdomain.

