import { useState } from 'react';
import { motion } from 'framer-motion';

export default function App() {
  const [showBooking, setShowBooking] = useState(false);

  return (
    <div className="font-sans text-gray-800 bg-white">
      {/* Hero */}
      <section className="h-screen flex flex-col justify-center items-center text-center bg-[url('https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e')] bg-cover bg-center">
        <h1 className="text-5xl font-bold text-white drop-shadow-xl">Affection Studios</h1>
        <h2 className="text-xl mt-2 text-white/90">Narrative Albums — ASNA</h2>
        <button onClick={() => setShowBooking(true)} className="mt-6 px-6 py-3 rounded-xl bg-white text-gray-900 font-semibold shadow-lg">Book Now</button>
      </section>

      {/* Services */}
      <section className="py-20 max-w-6xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-10">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {['Wedding Photography','Wedding Cinematic Videography','Pre-Wedding Shoots'].map((service,i)=>(
            <motion.div key={i} whileHover={{scale:1.05}} className="p-6 bg-gray-100 rounded-2xl shadow">
              <h3 className="text-xl font-semibold mb-2">{service}</h3>
              <p className="text-sm text-gray-600">Premium storytelling visuals crafted to preserve your moments forever.</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Portfolio */}
      <section className="py-20 bg-gray-50">
        <h2 className="text-3xl font-bold text-center mb-10">Portfolio</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto px-6">
          {[1,2,3,4,5,6].map((id)=>(
            <img key={id} className="rounded-xl shadow" src={`https://picsum.photos/500/500?random=${id}`} />
          ))}
        </div>
      </section>

      {/* Contact */}
      <section className="py-20 max-w-4xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-10">Contact Us</h2>
        <div className="bg-gray-100 p-6 rounded-2xl shadow text-center">
          <p className="text-lg">Email: contact@asna.com</p>
          <p className="text-lg mt-2">Phone: +91 90000 00000</p>
          <button onClick={()=>setShowBooking(true)} className="mt-6 px-6 py-3 bg-black text-white rounded-xl">Book a Shoot</button>
        </div>
      </section>

      {/* Booking Modal */}
      {showBooking && (
        <div className="fixed inset-0 bg-black/60 flex justify-center items-center p-4">
          <div className="bg-white p-6 rounded-xl max-w-md w-full shadow-xl">
            <h3 className="text-xl font-bold mb-4">Book Your Event</h3>
            <input className="w-full p-2 border rounded mb-3" placeholder="Name" />
            <input className="w-full p-2 border rounded mb-3" placeholder="Phone" />
            <input className="w-full p-2 border rounded mb-3" placeholder="Event Date" type="date" />
            <button className="w-full p-3 bg-black text-white rounded-lg mt-2">Submit</button>
            <button onClick={()=>setShowBooking(false)} className="w-full p-3 bg-gray-300 rounded-lg mt-2">Close</button>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="text-center py-6 bg-gray-900 text-white">© 2025 ASNA — Affection Studios</footer>
    </div>
  );
}
